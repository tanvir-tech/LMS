<div class=" text-light p-4 pt-0">

    <div class="row">
        <div class="col-lg-8 bg-secondary p-5">
            <h4>Important links here</h4>
            IEEE
            <br>
            Google Scholars
            <br>
            Researchgate
            <br>
            ....
            <br>
        </div>

        <div class="col-lg-4 bg-dark p-5">
            <h4>Contact us</h4>
            Librarian: +8801XXXXXXXXXX
            <br>
            Mail: librarian@gmail.com
            <br>
            

        </div>

    </div>









</div>
