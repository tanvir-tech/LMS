@extends('includes/master')
@section('content')
    <div class="container">
        
        
        
        <div class="card">
            <h1>
                {{ View::make('includes/flash-message') }}
            </h1>
        </div>
        






    </div>
@endsection
