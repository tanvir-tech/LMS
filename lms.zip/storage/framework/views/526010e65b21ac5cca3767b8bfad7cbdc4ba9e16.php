<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="card m-5">
            <div class="card-header d-flex justify-content-center">
                <h1>
                    Edit Book
                </h1>

            </div>
            <?php echo $__env->make('includes/flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <p>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($error); ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </p>
                </div>
            <?php endif; ?>
            <div class="card-body">
                <form class="row" action="<?php echo e(route('book.update' , $book->id)); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo method_field('PATCH'); ?>
                    <?php echo csrf_field(); ?>
                    <div class="col-md-6 p-4">
                        <label class="form-label">Book Name</label>
                        <input class="form-control" name="bookname" value="<?php echo e($book->bookname); ?>">
                    </div>
                    <div class="col-md-6 p-4">
                        <label class="form-label">Author Name</label>
                        <input class="form-control" name="authorname" value="<?php echo e($book->authorname); ?>">
                    </div>
                    <div class="col-md-6 p-4">
                        <label class="form-label">Publisher</label>
                        <input class="form-control" name="publisher" value="<?php echo e($book->publisher); ?>">
                    </div>
                    <div class="col-md-6 p-4">
                        <label class="form-label">Publish year</label>
                        <input type="number" class="form-control" name="year" value="<?php echo e($book->year); ?>">
                    </div>
                    <div class="col-md-6 p-4">
                        <label class="form-label">Category</label>
                        <input class="form-control" name="category" value="<?php echo e($book->category['id']); ?>">
                    </div>
                    <div class="col-md-6 p-4">
                        <label class="form-label">Edition</label>
                        <input type="number" class="form-control" name="edition" value="<?php echo e($book->edition); ?>">
                    </div>
                    <div class="col-md-6 p-4">
                        <label class="form-label">Language</label>
                        <input class="form-control" name="language" value="<?php echo e($book->language); ?>">
                    </div>
                    <div class="col-md-6 p-4">
                        <label class="form-label">Quantity</label>
                        <input type="number" class="form-control" name="quantity" value="<?php echo e($book->quantity); ?>">
                    </div>
                    <div class="col-md-6 p-4">
                        <label class="form-label">Call ID</label>
                        <input class="form-control" name="callid" value="<?php echo e($book->callid); ?>">
                    </div>

                    <div class="col-md-6 p-4">
                        <label for="bookcover">Book cover is not replaceable.</label>
                    </div>

                    <div class="col-md-4 p-4 m-2">
                        <button type="submit" class="btn btn-primary">Update Book</button>
                    </div>
                </form>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('includes/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tanvir/tanvir_pc/workspace/web-dev/my_Project_42/LMS/resources/views/backend/editBook.blade.php ENDPATH**/ ?>