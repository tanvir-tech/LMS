<?php $__env->startSection('content'); ?>
    <div class="container">


        <?php
            use App\Models\Category;
            $categories = Category::where('parent_id', null)->get();
        ?>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <section style="background-color: rgba(238, 238, 238, 0.664);" class="m-5">
                <div class="container p-5">

                    <a class=" " href="/category/<?php echo e($category->id); ?>">
                        <h2 class="text-center text-white mb-5"><strong><?php echo e($category->name); ?></strong></h2>
                    </a>
                    <div class="row">
                        <?php
                            $subcategories = Category::where('parent_id', $category->id)->get();
                        ?>

                        <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-lg-4 col-md-12 mb-4">
                                <div class="card">
                                    <div class="card-body bg-warning">

                                    </div>
                                    <div class="card-footer ">
                                        <div class="card-title">
                                            <a href="/category/<?php echo e($subcategory->id); ?>">
                                                <h1 class="text-center">
                                                    <?php echo e($subcategory->name); ?>

                                                </h1>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </div>
                </div>
            </section>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>






    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('includes/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tanvir/tanvir_pc/workspace/web-dev/my_Project_42/LMS/resources/views/frontend/categories.blade.php ENDPATH**/ ?>