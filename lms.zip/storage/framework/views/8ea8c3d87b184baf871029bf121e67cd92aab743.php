<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="card m-5">
            <div class="card-header d-flex justify-content-center">
                <h1>
                    Add a new Category
                </h1>

            </div>
            <?php echo $__env->make('includes/flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <p>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($error); ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </p>

                </div>
            <?php endif; ?>
            <div class="card-body">
                <form class="row" action="/admin/createCat" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="col-md-6 p-4">
                        <label class="form-label">Category name</label>
                        <input class="form-control" name="name">
                    </div>



                    <div class="col-md-6 p-4">
                        <label class="form-label">Parent category name</label>
                        <select class="form-select" aria-label="Default select example" name="parent_id">

                            <option selected>Not sub-category</option>

                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </select>
                    </div>

                    <div class="col-md-4 p-4 m-2">
                        <button type="submit" class="btn btn-primary">Creat category</button>
                    </div>


                </form>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('includes/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tanvir/tanvir_pc/workspace/web-dev/my_Project_42/LMS/resources/views/backend/createCat.blade.php ENDPATH**/ ?>