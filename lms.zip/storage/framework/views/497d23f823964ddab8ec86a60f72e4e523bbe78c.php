<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /home/tanvir/tanvir_pc/workspace/web-dev/my_Project_42/LMS/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/button.blade.php ENDPATH**/ ?>