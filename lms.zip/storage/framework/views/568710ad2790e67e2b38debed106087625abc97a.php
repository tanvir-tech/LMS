<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>LMS</title>
    <?php echo e(View::make('includes/styles')); ?>

</head>





<body style="background-image: url('<?php echo e(asset("images/bg-lms.jpg")); ?>'); background-size: contain;">


    <div >

        <?php echo e(View::make('includes/header')); ?>




        <div class="mt-5 pt-5">
            <?php echo $__env->yieldContent('content'); ?>
        </div>



        <?php echo e(View::make('includes/footer')); ?>







        <?php echo e(View::make('includes/scripts')); ?>

</body>

</html>
<?php /**PATH /home/tanvir/tanvir_pc/workspace/web-dev/my_Project_42/LMS/resources/views/includes/master.blade.php ENDPATH**/ ?>