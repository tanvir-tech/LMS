<?php $__env->startSection('content'); ?>
    <div class="container">
        
        
        
        <div class="card">
            <h1><?php echo $__env->make('includes/flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></h1>
        </div>
        






    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('includes/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tanvir/tanvir_pc/workspace/web-dev/my_Project_42/LMS/resources/views//includes/messagepage.blade.php ENDPATH**/ ?>