<div class="hidden sm:block">
    <div class="py-8">
        <div class="border-t border-gray-200"></div>
    </div>
</div>
<?php /**PATH /home/tanvir/tanvir_pc/workspace/web-dev/my_Project_42/LMS/vendor/laravel/jetstream/src/../resources/views/components/section-border.blade.php ENDPATH**/ ?>