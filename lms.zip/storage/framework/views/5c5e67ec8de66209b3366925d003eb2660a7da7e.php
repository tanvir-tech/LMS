<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <?php echo $__env->make('includes/flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            <div class="card p-2">
                <div class="row">
                    <div class="col-md-3">
                        <img class="bookimg" src="<?php echo e(asset('gallery/' . $book['bookcoverlink'])); ?>" alt="Book photo">
                    </div>
                    <div class="col-md-6">
                        <div class="card-header">
                            <h3><?php echo e($book['bookname']); ?></h3>
                            <h5>Edition : <?php echo e($book['edition']); ?></h5>
                            <h6>Author : <?php echo e($book['authorname']); ?></h6>
                            <h6>Category: <?php echo e($book['category']['name']); ?></h6>
                            <h6>Publisher: <?php echo e($book['publisher']); ?></h6>
                            <h6>Publication year: <?php echo e($book['year']); ?></h6>
                        </div>

                        

                    </div>
                    <div class="col-md-3">
                        <div class="card-footer">
                            <h6>Available Quantity: <?php echo e($book['quantity']); ?></h6>
                            <h6>Call ID: <?php echo e($book['callid']); ?></h6>
                       
                            

                            <?php if(Auth::guard('web')->check() && Auth::user()->hasRole('admin')): ?>
                                <div class="row">
                                    <div class="col">
                                        <a href="/admin/book/<?php echo e($book->id); ?>/edit" class="text-white btn btn-warning">Edit</a>
                                    </div>
                                    <div class="col">
                                        <form action="<?php echo e(route('book.destroy', ['book' => $book->id])); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger">Delete</button>
                                        </form>
                                    </div>
                                </div>
                            <?php elseif(Auth::guard('web')->check() && Auth::user()->hasRole('user')): ?>
                                <a href="/book/<?php echo e($book->id); ?>/borrow" class="text-white btn btn-success">Borrow</a>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                </div>

                
            </div>
            
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>









    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('includes/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tanvir/tanvir_pc/workspace/web-dev/my_Project_42/LMS/resources/views/frontend/home.blade.php ENDPATH**/ ?>