<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
    integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">



<!-- App favicon -->
<link rel="shortcut icon" href="<?php echo e(asset('images/favicon.ico')); ?>">


<!-- <link rel="stylesheet" href="<?php echo e(asset('css/flip.css')); ?>"> -->

<!-- Bootstrap Css -->
<link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" id="bootstrap-style" rel="stylesheet" type="text/css" />
<!-- Icons Css -->
<link href="<?php echo e(asset('css/icons.min.css')); ?>" rel="stylesheet" type="text/css" />
<!-- App Css-->
<link href="<?php echo e(asset('css/app.min.css')); ?>" id="app-style" rel="stylesheet" type="text/css" />


<?php /**PATH /home/tanvir/tanvir_pc/workspace/web-dev/project_42/LMS/resources/views/includes/styles.blade.php ENDPATH**/ ?>