<?php echo e($slot); ?>

<?php /**PATH /home/tanvir/tanvir_pc/workspace/web-dev/my_Project_42/LMS/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>