<?php $__env->startSection('content'); ?>
    <div class="container">


        



        <section style="background-color: rgba(238, 238, 238, 0.664);" class="m-5">
            <div class="container p-5">
                <h2 class="text-center text-white mb-5"><strong>Categories</strong></h2>

                <div class="row">
                    <div class="col-lg-4 col-md-12 mb-4">
                        <div class="card">
                            <div class="card-body bg-warning">

                            </div>
                            <div class="card-footer ">
                                <div class="card-title">
                                    <h1 class="text-center">
                                        ICT
                                    </h1>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-12 mb-4">
                        <div class="card">
                            <div class="card-body bg-warning">

                            </div>
                            <div class="card-footer ">
                                <div class="card-title">
                                    <h1 class="text-center">
                                        Math
                                    </h1>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-12 mb-4">
                        <div class="card">
                            <div class="card-body bg-warning">

                            </div>
                            <div class="card-footer ">
                                <div class="card-title">
                                    <h1 class="text-center">
                                        Physics
                                    </h1>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-4 col-md-12 mb-4">
                        <div class="card">
                            <div class="card-body bg-warning">

                            </div>
                            <div class="card-footer ">
                                <div class="card-title">
                                    <h1 class="text-center">
                                        English
                                    </h1>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-12 mb-4">
                        <div class="card">
                            <div class="card-body bg-warning">

                            </div>
                            <div class="card-footer ">
                                <div class="card-title">
                                    <h1 class="text-center">
                                        Biology
                                    </h1>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-12 mb-4">
                        <div class="card">
                            <div class="card-body bg-warning">

                            </div>
                            <div class="card-footer ">
                                <div class="card-title">
                                    <h1 class="text-center">
                                        Electrical
                                    </h1>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-4 col-md-12 mb-4">
                        <div class="card">
                            <div class="card-body bg-warning">

                            </div>
                            <div class="card-footer ">
                                <div class="card-title">
                                    <h1 class="text-center">
                                        Statistics
                                    </h1>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-12 mb-4">
                        <div class="card">
                            <div class="card-body bg-warning">

                            </div>
                            <div class="card-footer ">
                                <div class="card-title">
                                    <h1 class="text-center">
                                        Social Science
                                    </h1>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-12 mb-4">
                        <div class="card">
                            <div class="card-body bg-warning">

                            </div>
                            <div class="card-footer ">
                                <div class="card-title">
                                    <h1 class="text-center">
                                        Papers
                                    </h1>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


            </div>

        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('includes/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tanvir/tanvir_pc/workspace/web-dev/project_42/LMS/resources/views/pages/home.blade.php ENDPATH**/ ?>