<?php $__env->startSection('content'); ?>
    <div class="container mt-5">


        <?php echo $__env->make('includes/flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        <div class="card m-5">
            <div class="card-header p-3">
                <h3 class=" d-flex justify-content-center ">
                    List of book issued
                </h3>
                <a href="/admin/remind/all/issue" class="text-white btn btn-primary d-flex justify-content-center">Remind all</a>
            </div>
            <div class="card-body">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Book_ID</th>
                            <th scope="col">User_ID</th>
                            <th scope="col">Approval</th>
                            <th scope="col">Date of Return</th>
                            <th>Late</th>
                            <th>Fine</th>
                            <th scope="col" colspan="2">Option</th>
                        </tr>
                    </thead>
                    <tbody>
                        
                        <?php
                            use Carbon\Carbon;
                            $today = Carbon::now();
                        ?>
                        <?php $__currentLoopData = $issues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $issue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($issue['id']); ?></th>
                                <td><?php echo e($issue['book_id']); ?></td>
                                <td><?php echo e($issue['user_id']); ?></td>
                                <td><?php echo e($issue['approval']); ?></td>
                                <td><?php echo e($issue['date_of_return']); ?></td>
                                <td>
                                    <?php
                                        // $returnday = date_create($issue['date_of_return']);
                                        // $late=date_diff($returnday,$today)->format('%d days');
                                        // $late=date_diff($today,$returnday)->format('%R%a days');
                                        
                                        // $late = $today->diff($returnday)->days;
                                        $late = $today->diff($issue['date_of_return'])->format('%R%a days');
                                        
                                        if (str_contains($late, '+')) {
                                            $lateint = 0;
                                        } else {
                                            $lateint = intval($today->diff($issue['date_of_return'])->format('%a'));
                                        }
                                        
                                    ?>
                                    <?php echo e($lateint); ?> days
                                </td>
                                <td><?php echo e(10 * $lateint); ?> Taka</td>
                                <td>
                                    <a href="/admin/issue/<?php echo e($issue->id); ?>/renew"
                                        class="text-white btn btn-warning">Renew</a>
                                    <a href="/admin/issue/<?php echo e($issue->id); ?>/receive"
                                        class="text-white btn btn-success">Receive</a>
                                    <a href="/admin/remind/issue/<?php echo e($issue->id); ?>"
                                        class="text-white btn btn-danger">Remind</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>












    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('includes/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tanvir/tanvir_pc/workspace/web-dev/my_Project_42/LMS/resources/views/backend/issueList.blade.php ENDPATH**/ ?>