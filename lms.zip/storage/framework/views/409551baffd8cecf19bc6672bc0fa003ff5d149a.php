<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="card m-5">
            <div class="card-header d-flex justify-content-center">
                <h1>
                    Add a new Book
                </h1>

            </div>
            <?php echo $__env->make('includes/flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <p>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($error); ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </p>

                </div>
            <?php endif; ?>
            <div class="card-body">
                <form class="row" action="/admin/book" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="col-md-6 p-4">
                        <label class="form-label">Book Name</label>
                        <input class="form-control" name="bookname">
                    </div>
                    <div class="col-md-6 p-4">
                        <label class="form-label">Author Name</label>
                        <input class="form-control" name="authorname">
                    </div>
                    <div class="col-md-6 p-4">
                        <label class="form-label">Publisher</label>
                        <input class="form-control" name="publisher">
                    </div>
                    <div class="col-md-6 p-4">
                        <label class="form-label">Publish year</label>
                        <input type="number" class="form-control" name="year">
                    </div>
                    <div class="col-md-6 p-4">
                        <label class="form-label">Edition</label>
                        <input type="number" class="form-control" name="edition">
                    </div>
                    <div class="col-md-6 p-4">
                        <label class="form-label">Language</label>
                        <input class="form-control" name="language">
                    </div>
                    
                    
                    <div class="col-md-6 p-4">
                        <?php
                            use App\Models\Category;
                            $categories = Category::all();
                        ?>
                        <label class="form-label">Category </label>
                        <select class="form-select" aria-label="Default select example" name="category_id">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>


                    <div class="col-md-6 p-4">
                        <label class="form-label">Quantity</label>
                        <input type="number" class="form-control" name="quantity">
                    </div>
                    <div class="col-md-6 p-4">
                        <label class="form-label">Call ID</label>
                        <input class="form-control" name="callid">
                    </div>

                    <div class="col-md-6 p-4">
                        <label for="bookcover">Choose a book cover:</label>
                        <input type="file" id="bookcover" name="bookcover">
                    </div>
                    <div class="row"></div>

                    <div class="col-md-4 p-4 m-2">
                        <button type="submit" class="btn btn-primary">Add Book</button>
                    </div>


                </form>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('includes/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tanvir/tanvir_pc/workspace/web-dev/my_Project_42/LMS/resources/views/backend/createBook.blade.php ENDPATH**/ ?>